//
//  controlador_basico.swift
//  boceto_2
//
//  Created by alumno on 22/9/25.
//

import Foundation
import SwiftUI

@MainActor
@Observable
public class ControladorBasico{
    var clicks = 0
}
