//
//  Casos.swift
//  boceto_2
//
//  Created by alumno on 26/9/25.
//

enum SaboresPalomitas: String, CaseIterable, Identifiable{
    case Mantequilla
    case Natural
    case QuesoChedar
    case Doritos
    case Proteina
    
    var id: Self { self }
}

enum GeneroPeliculas: String, CaseIterable, Identifiable{
    case Aleatoria
    case Accion
    case Comedia
    case Terror
    case Drama
    case SiFi
    
    var id: Self { self }
}

enum SeleccionJuego: String, CaseIterable, Identifiable{
    case ElQueCaiga
    case MarioParty
    case HaloReach
    case MarioKart
    case GearsOfWar
    case MortalKombat
    
    var id: Self { self }
}
