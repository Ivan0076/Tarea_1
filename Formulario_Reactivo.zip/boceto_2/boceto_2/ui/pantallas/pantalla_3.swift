//
//  pantalla_3.swift
//  boceto_2
//
//  Created by alumno on 22/9/25.
//

import SwiftUI

struct PantallaOpciones: View {
    @State var valor_slider: Float = 0
    @State var disponibilidad: Bool = false
    @State var quiere_palomitas: Bool = false
    @State var palomitas_color: Bool = false
    @State var ver_peliculas: Bool = false
    @State var jugar_videojuego: Bool = false
    @State var apedrear_brujas: Bool = false
    @State var genero_de_peliculas: GeneroPeliculas = .Aleatoria
    @State var sabor_de_palomitas: SaboresPalomitas = .Mantequilla
    @State var seleccion_juego: SeleccionJuego = .ElQueCaiga
    
    var body: some View{
        ScrollView(){
            VStack{
                Text("Formulario para hacer algo el sábado")
                HStack{
                    Spacer()
                    Text("¿Estás disponible el sábado en la noche?")
                    Spacer()
                    CajaSeleccionada(checado: $disponibilidad, tamaño: 25)
                    Spacer()
                }
                Spacer()
                if(disponibilidad == true){
                    HStack{
                        Spacer()
                        Text("¿Quieres ver una película?")
                        Spacer()
                        CajaSeleccionada(checado: $ver_peliculas, tamaño: 25)
                        Spacer()
                    }
                    if ver_peliculas == true {
                        HStack{
                            Text("¿Qué genero de pelicula quieres ver?")
                            Picker(selection: $genero_de_peliculas, label: Text("Sabor de palmolitas")) {
                                    Text("Aleatoria").tag(GeneroPeliculas.Aleatoria)
                                    Text("Accion").tag(GeneroPeliculas.Accion)
                                    Text("Comedia").tag(GeneroPeliculas.Comedia)
                                    Text("Terror").tag(GeneroPeliculas.Terror)
                                    Text("Drama").tag(GeneroPeliculas.Drama)
                                    Text("SiFi").tag(GeneroPeliculas.SiFi)
                            }
                        }
                        HStack{
                            Spacer()
                            Text("¿Quieres palmolitas?")
                            Spacer()
                            CajaSeleccionada(checado: $quiere_palomitas, tamaño: 25)
                            Spacer()
                        }
                        if quiere_palomitas == true {
                            HStack{
                                Text("¿Cuál sabor?")
                                Picker(selection: $sabor_de_palomitas, label: Text("Sabor de palmolitas")) {
                                        Text("Naturales").tag(SaboresPalomitas.Natural)
                                        Text("Mantequilla").tag(SaboresPalomitas.Mantequilla)
                                        Text("Queso Chedar").tag(SaboresPalomitas.QuesoChedar)
                                        Text("Doritos").tag(SaboresPalomitas.Doritos)
                                        Text("Proteina").tag(SaboresPalomitas.Proteina)
                                }
                                
                            }
                            Text("Cantidad de palomitas: \(valor_slider)")
                            Slider(value: $valor_slider, in: 0...20000)
                            
                            Text("Quieres palomitas de color?")
                            Spacer()
                            CajaSeleccionada(checado: $palomitas_color, tamaño: 25)
                            Spacer()
                            if palomitas_color == true {
                                Text("Selecciona el color de las palomitas")
                                ColorPicker("Color de palomitas", selection: /*@START_MENU_TOKEN@*/.constant(.red)/*@END_MENU_TOKEN@*/)
                            }
                        }
                    }
                    HStack{
                        Spacer()
                        Text("¿Quieres jugar videojuegos?")
                        Spacer()
                        CajaSeleccionada(checado: $jugar_videojuego, tamaño: 25)
                        Spacer()
                    }
                    if jugar_videojuego == true {
                        HStack{
                            Text("¿Qué juego quieres jugar?")
                            Picker(selection: $seleccion_juego, label: Text("Sabor de palmolitas")) {
                                Text("El que caiga").tag(SeleccionJuego.ElQueCaiga)
                                Text("Mario Kart").tag(SeleccionJuego.MarioKart)
                                Text("Halo: Reach").tag(SeleccionJuego.HaloReach)
                                Text("Super Mario Party").tag(SeleccionJuego.MarioParty)
                                Text("Gears of War").tag(SeleccionJuego.GearsOfWar)
                                Text("Mortal Kombat 11").tag(SeleccionJuego.MortalKombat)
                            }
                        }
                    }
                    HStack{
                        Spacer()
                        Text("¿Quieres ir a apedrear brujas en el cerro?")
                        Spacer()
                        CajaSeleccionada(checado: $apedrear_brujas, tamaño: 25)
                        Spacer()
                    }
                    if apedrear_brujas == true {
                        HStack{
                            Text("Nos vemos en el cerro a las 8:00 P.M")
                            }
                        }
                    }
                }
            }
        }
    }
    

#Preview {
    PantallaOpciones()
        .environment(ControladorBasico())
}
